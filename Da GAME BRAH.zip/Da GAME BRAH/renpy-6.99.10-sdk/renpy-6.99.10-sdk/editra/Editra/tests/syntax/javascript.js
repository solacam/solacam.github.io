// Syntax Highlighting Test File for JavaScript
// Some Comments about this file

function HelloAlert ()
{
    alert("Hello World!")
}

function count(to)
{
    for (i = 0; i <= to; i++)
    {
        document.write("The number is " + i)
        document.write("<br />")
    }
}
