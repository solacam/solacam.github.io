import renpy

# Pass the file off to the system editor (as determined by file associations).
Editor = renpy.editor.SystemEditor
