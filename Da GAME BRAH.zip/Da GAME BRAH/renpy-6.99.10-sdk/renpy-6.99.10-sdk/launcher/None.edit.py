import renpy

# Do nothing when the editor is invoked.
Editor = renpy.editor.Editor
