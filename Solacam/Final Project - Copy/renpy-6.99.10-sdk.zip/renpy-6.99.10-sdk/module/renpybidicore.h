#ifndef RENPYBIDICORE_H
#define RENPYBIDICORE_H
#include <Python.h>

PyObject *renpybidi_log2vis(PyObject *s, int *direction);
#endif
